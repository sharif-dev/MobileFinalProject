package com.example.nobintest.graphActivity.candlaDataSets;

public enum Range {
    daily,
    weekly,
    oneMonth,
    threeMonth,
    sixMonth,
    yearly,
}
